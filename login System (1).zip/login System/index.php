<?php
session_start();


if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form id="login-form">
            <h2>Login</h2>
            <input type="text" id="login-username" placeholder="Username" required>
            <input type="password" id="login-password" placeholder="Password" required>
            <button type="submit">Login</button>
            <p><a href="#">Forgot Password?</a></p>
            <p>Don't have an account? <a href="#" id="show-register">Sign up</a></p>
        </form>

        <form id="register-form" style="display: none;">
            <h2>Register</h2>
            <input type="text" id="register-username" placeholder="Username" required>
            <input type="email" id="register-email" placeholder="Email" required>
            <input type="password" id="register-password" placeholder="Password" required>
            <button type="submit">Sign Up</button>
            <p>Already have an account? <a href="#" id="show-login">Login</a></p>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>
