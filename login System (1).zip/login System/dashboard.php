<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Be a Technologist</title>
    <link href="style3.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>BE A TECHNOLOGIST!</h1>

        <form action="connect.php" method="post" enctype="multipart/form-data">
    <div class="form-group"><input type="text" name="full_name" placeholder="Full Name" required></div>
    <div class="form-group"><input type="date" name="birth_date" required></div>
    <div class="form-group"><input type="text" name="address" placeholder="Address" required></div>
    <div class="form-group"><input type="tel" name="phone_no" placeholder="Phone No." required></div>
    <div class="form-group"><input type="email" name="email" placeholder="Email" required></div>
    <div class="form-group"><input type="text" name="grade" placeholder="Grade" required></div>

    <div class="upload-box">
        <span>UPLOAD YOUR DOCUMENTS HERE</span>
        <input type="file" name="document">
    </div>

    <div class="buttons">
        <a href="logout.php" class="go-back">Logout</a>
        <button type="submit" class="submit">Submit</button>
    </div>
</form>

