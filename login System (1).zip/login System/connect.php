<?php
session_start();
require "config.php";

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "message" => "You must be logged in to submit the form."]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION["user_id"];
    $full_name = trim($_POST["full_name"]);
    $birth_date = $_POST["birth_date"];
    $address = trim($_POST["address"]);
    $phone_no = trim($_POST["phone_no"]);
    $email = trim($_POST["email"]);
    $grade = trim($_POST["grade"]);

    $upload_dir = "uploads/";
    $file_name = basename($_FILES["document"]["name"]);
    $target_file = $upload_dir . $file_name;
    move_uploaded_file($_FILES["document"]["tmp_name"], $target_file);

    try {
        $stmt = $conn->prepare("INSERT INTO technologists (user_id, full_name, birth_date, address, phone_no, email, grade, document_path) 
                                VALUES (:user_id, :full_name, :birth_date, :address, :phone_no, :email, :grade, :document_path)");
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":full_name", $full_name);
        $stmt->bindParam(":birth_date", $birth_date);
        $stmt->bindParam(":address", $address);
        $stmt->bindParam(":phone_no", $phone_no);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":grade", $grade);
        $stmt->bindParam(":document_path", $target_file);
        $stmt->execute();

        echo "<div class='success-message'>Form submitted successfully! Redirecting...</div>";
        echo "<script>setTimeout(function(){ window.location.href = 'dashboard.php'; }, 3000);</script>";
    } catch (PDOException $e) {
        echo "<div class='error-message'>Error: " . $e->getMessage() . "</div>";
    }
}
?>