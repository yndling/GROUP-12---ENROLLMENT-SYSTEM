<?php
$servername = "localhost"; 
$username = "root"; 
$password = "";
$dbname = "try"; 


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $grade = $_POST['grade'];

    $sql = "INSERT INTO form (fullname, birthdate, address, number, email, grade) 
            VALUES ('$fullname', '$birthdate', '$address', '$number', '$email', '$grade')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Record added successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>