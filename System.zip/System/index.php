<?php
session_start();

if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form id="login-form" action="login.php" method="POST">
            <h2>Login</h2>
            <input type="text" id="login-username" name="username" placeholder="Username" required>
            <input type="password" id="login-password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
            <p><a href="#">Forgot Password?</a></p>
            <p>Don't have an account? <a href="#" id="show-register">Sign up</a></p>
        </form>

        <form id="register-form" action="register.php" method="POST" style="display: none;">
            <h2>Register</h2>
            <input type="text" id="register-username" name="username" placeholder="Username" required>
            <input type="email" id="register-email" name="email" placeholder="Email" required>
            <input type="password" id="register-password" name="password" placeholder="Password" required>

            <select id="register-role" name="role" required>
                <option value="user" selected>User</option>
                <option value="admin">Admin</option>
            </select>

            <button type="submit">Sign Up</button>
            <p>Already have an account? <a href="#" id="show-login">Login</a></p>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const loginForm = document.getElementById("login-form");
            const registerForm = document.getElementById("register-form");
            const showRegister = document.getElementById("show-register");
            const showLogin = document.getElementById("show-login");

            showRegister.addEventListener("click", function (e) {
                e.preventDefault();
                loginForm.style.display = "none";
                registerForm.style.display = "block";
            });

            showLogin.addEventListener("click", function (e) {
                e.preventDefault();
                registerForm.style.display = "none";
                loginForm.style.display = "block";
            });
        });
    </script>
</body>
</html>
