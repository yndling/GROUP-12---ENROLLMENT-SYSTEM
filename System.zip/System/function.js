document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('student-form'); 
    const tableBody = document.querySelector('table tbody'); 
    let currentEditRow = null; 
    let isEditing = false; 
    
    form.addEventListener('submit', function (event) {
        event.preventDefault(); 

        const firstName = document.getElementById('first-name').value.trim();
        const middleName = document.getElementById('middle-name').value.trim(); 
        const lastName = document.getElementById('last-name').value.trim();
        const contactNumber = document.getElementById('contact-number').value.trim();
        const grade = document.getElementById('grade').value.trim();
        const enrollmentDate = document.getElementById('enrollment-date').value;

        if (!firstName || !lastName || !contactNumber || !grade || !enrollmentDate) {
            alert('Please fill in all required fields.');
            return;
        }

        if (isEditing) {
            currentEditRow.innerHTML = `
                <td>${firstName}</td>
                <td>${middleName ? middleName : 'N/A'}</td>
                <td>${lastName}</td>
                <td>${contactNumber}</td>
                <td>${grade}</td>
                <td>${formatDate(enrollmentDate)}</td> 
                <td>
                    <div class="btn-for-action">
                        <a href="#" class="btn btn-warning btn-sm edit">Update</a>
                        <a href="#" class="btn btn-danger btn-sm delete">Delete</a>
                    </div>
                </td>
            `;
            isEditing = false; 
            currentEditRow = null; 
        } else {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${firstName}</td>
                <td>${middleName ? middleName : 'N/A'}</td>
                <td>${lastName}</td>
                <td>${contactNumber}</td>
                <td>${grade}</td>
                <td>${formatDate(enrollmentDate)}</td> 
                <td>
                    <div class="btn-for-action">
                        <a href="#" class="btn btn-warning btn-sm edit">Update</a>
                        <a href="#" class="btn btn-danger btn-sm delete">Delete</a>
                    </div>
                </td>
            `;
            tableBody.appendChild(newRow);
        }

        form.reset();
    });

    tableBody.addEventListener('click', function (event) {
        if (event.target.classList.contains('edit')) {
            const row = event.target.closest('tr');
            const cells = row.querySelectorAll('td');

            document.getElementById('first-name').value = cells[0].textContent;
            document.getElementById('middle-name').value = cells[1].textContent === 'N/A' ? '' : cells[1].textContent;
            document.getElementById('last-name').value = cells[2].textContent;
            document.getElementById('contact-number').value = cells[3].textContent;
            document.getElementById('grade').value = cells[4].textContent;
            document.getElementById('enrollment-date').value = cells[5].textContent.split('/').reverse().join('-'); 

            currentEditRow = row; 
            isEditing = true; 
            
        }

        if (event.target.classList.contains('delete')) {
            const row = event.target.closest('tr');
            row.remove(); 
        }
    });

    function formatDate(dateString) {
        const date = new Date(dateString);
        const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
        return date.toLocaleDateString('en-US', options).replace(/(\d+)\/(\d+)\/(\d+)/, '$1/$2/$3'); // Format to MM/DD/YYYY
    }
});