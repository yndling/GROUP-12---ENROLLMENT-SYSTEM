<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

echo "<h1 class='welcome-message'>Welcome, " . $_SESSION['username'] . "!</h1>";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DASHBOARD</title>
    <link rel="stylesheet" href="studentcss.css">
</head>
<body>
    <nav>
        <ul class="nav-menu">
        <a href="logout.php" class="logout-btn">Logout</a>
        </ul>
    
    </nav>
<header>
    <h1>ENROLLMENT DASHBOARD</h1>
</header>

<div class="container">
    <h2>Enrollment Details</h2>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Grade</th>
                <th>Enrollment Date</th>
            </tr>
        </thead>
        <tbody> </tbody>
    </table>
</div>

</body>
</html>