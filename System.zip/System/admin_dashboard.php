<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

echo "<h1 class='welcome-message' style='color: white;'>Welcome, Admin " . $_SESSION['username'] . "!</h1>";

$edit_mode = false;
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id = $_GET['edit'];
    $result = $conn->query("SELECT * FROM students WHERE id=$id");
    $student = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <ul class="nav-menu">
        <a href="logout.php" class="logout-btn">Logout</a>
        </ul>
    </nav>

    <header>
    <h1>Admin Dashboard</h1>
</header>

<div class="container">
    <h2><?= $edit_mode ? "Edit" : "Add New" ?> Student</h2>
    
    <form method="POST" action="<?= $edit_mode ? 'edit.php' : 'create.php' ?>">
        <?php if ($edit_mode): ?>
            <input type="hidden" name="id" value="<?= $student['id'] ?>">
        <?php endif; ?>
        <input type="text" name="first_name" required placeholder="First Name" value="<?= $edit_mode ? $student['first_name'] : '' ?>">
        <input type="text" name="middle_name" placeholder="Middle Name" value="<?= $edit_mode ? $student['middle_name'] : '' ?>">
        <input type="text" name="last_name" required placeholder="Last Name" value="<?= $edit_mode ? $student['last_name'] : '' ?>">
        <input type="text" name="contact_number" required placeholder="Contact No." value="<?= $edit_mode ? $student['contact_number'] : '' ?>">
        <input type="number" name="grade_level" required placeholder="Grade Level" value="<?= $edit_mode ? $student['grade_level'] : '' ?>">
        <input type="date" name="enrollment_date" required value="<?= $edit_mode ? $student['enrollment_date'] : '' ?>">
        <button type="submit"><?= $edit_mode ? 'Update' : 'Create' ?></button>
    </form>

    <h2>Enrollment Details</h2>
    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Last Name</th>
                <th>Contact</th>
                <th>Grade</th>
                <th>Enrollment Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $students = $conn->query("SELECT * FROM students ORDER BY id DESC");
            while ($row = $students->fetch_assoc()):
            ?>
            <tr>
                <td><?= htmlspecialchars($row['first_name']) ?></td>
                <td><?= htmlspecialchars($row['middle_name']) ?></td>
                <td><?= htmlspecialchars($row['last_name']) ?></td>
                <td><?= htmlspecialchars($row['contact_number']) ?></td>
                <td><?= htmlspecialchars($row['grade_level']) ?></td>
                <td><?= htmlspecialchars($row['enrollment_date']) ?></td>
                <td>
                    <a href="admin_dashboard.php?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
