<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first = $_POST['first_name'];
    $middle = $_POST['middle_name'];
    $last = $_POST['last_name'];
    $contact = $_POST['contact_number'];
    $grade = $_POST['grade_level'];
    $date = $_POST['enrollment_date'];

    $stmt = $conn->prepare("INSERT INTO students (first_name, middle_name, last_name, contact_number, grade_level, enrollment_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $first, $middle, $last, $contact, $grade, $date);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_dashboard.php");
    exit;
}
?>
