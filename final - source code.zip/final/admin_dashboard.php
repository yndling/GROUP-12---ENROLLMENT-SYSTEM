<?php
session_start();
require 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Junior High School Enrollment Dashboard</title>
  <link rel="stylesheet" href="styles.css" />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

</head>
<body>
<nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="admin_dashboard.php">DASHBOARD</a></li>
      <li><a href="reports.php">Reports</a></li>
      
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

<header>
  <h1>Admin Dashboard</h1>
</header>

<div class="container">
  <h2 id="formTitle">Add New Student</h2>
  <form id="studentForm">
      <input type="hidden" id="studentId" name="id" />
      <input type="text" id="first_name" name="first_name" required placeholder="First Name" />
      <input type="text" id="middle_name" name="middle_name" placeholder="Middle Name" />
      <input type="text" id="last_name" name="last_name" required placeholder="Last Name" />
      <input type="text" id="contact_number" name="contact_number" required placeholder="Contact No." />
      <input type="number" id="grade_level" name="grade_level" required placeholder="Grade Level" min="1" max="12" />
      <input type="date" id="enrollment_date" name="enrollment_date" required />
      <div class="button-container">
        <button type="submit" id="submitBtn">Create</button>
        <button type="button" id="cancelEditBtn" class="hidden">Cancel Edit</button>
      </div>
  </form>

  <h2>Enrollment Details</h2>
  <table>
      <thead>
          <tr>
              <th>First Name</th>
              <th>Middle Name</th>
              <th>Last Name</th>
              <th>Contact</th>
              <th>Grade</th>
              <th>Enrollment Date</th>
              <th>Actions</th>
          </tr>
      </thead>
      <tbody id="studentsTableBody">
          <!-- Students loaded dynamically here -->
      </tbody>
  </table>
</div>

<script>
const API_URL = 'api.php'; // Change to your API endpoint

const form = document.getElementById('studentForm');
const studentIdInput = document.getElementById('studentId');
const firstNameInput = document.getElementById('first_name');
const middleNameInput = document.getElementById('middle_name');
const lastNameInput = document.getElementById('last_name');
const contactNumberInput = document.getElementById('contact_number');
const gradeLevelInput = document.getElementById('grade_level');
const enrollmentDateInput = document.getElementById('enrollment_date');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const submitBtn = document.getElementById('submitBtn');
const formTitle = document.getElementById('formTitle');
const tableBody = document.getElementById('studentsTableBody');

let isEditing = false;

function fetchStudents() {
  fetch(API_URL)
    .then(res => res.json())
    .then(data => {
      if (data.status === 'success') {
        renderTable(data.data);
      } else {
        alert('Failed to load students: ' + data.message);
      }
    })
    .catch(err => alert('Error fetching students: ' + err));
}

function renderTable(students) {
  tableBody.innerHTML = '';
  students.forEach(student => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(student.first_name)}</td>
      <td>${escapeHtml(student.middle_name || '')}</td>
      <td>${escapeHtml(student.last_name)}</td>
      <td>${escapeHtml(student.contact_number)}</td>
      <td>${escapeHtml(student.grade_level)}</td>
      <td>${escapeHtml(student.enrollment_date)}</td>
      <td>
        <button data-id="${student.id}" class="editBtn">Edit</button>
        <button data-id="${student.id}" class="deleteBtn">Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

function escapeHtml(text) {
  if (!text) return '';
  return text.replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
}

form.addEventListener('submit', e => {
  e.preventDefault();
  
  const studentData = {
    first_name: firstNameInput.value.trim(),
    middle_name: middleNameInput.value.trim(),
    last_name: lastNameInput.value.trim(),
    contact_number: contactNumberInput.value.trim(),
    grade_level: parseInt(gradeLevelInput.value, 10),
    enrollment_date: enrollmentDateInput.value
  };

  if (isEditing) {
    studentData.id = parseInt(studentIdInput.value, 10);
    updateStudent(studentData);
  } else {
    createStudent(studentData);
  }
});

cancelEditBtn.addEventListener('click', () => {
  resetForm();
});

tableBody.addEventListener('click', e => {
  if (e.target.classList.contains('editBtn')) {
    const id = e.target.dataset.id;
    editStudent(id);
  } else if (e.target.classList.contains('deleteBtn')) {
    const id = e.target.dataset.id;
    if (confirm('Are you sure you want to delete this student?')) {
      deleteStudent(id);
    }
  }
});

function createStudent(student) {
  fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(student)
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'success') {
      alert('Student added successfully!');
      fetchStudents();
      resetForm();
    } else {
      alert('Failed to add student: ' + data.message);
    }
  })
  .catch(err => alert('Error: ' + err));
}

function editStudent(id) {
  fetch(API_URL)
    .then(res => res.json())
    .then(data => {
      if (data.status === 'success') {
        const student = data.data.find(s => s.id == id);
        if (student) {
          studentIdInput.value = student.id;
          firstNameInput.value = student.first_name;
          middleNameInput.value = student.middle_name;
          lastNameInput.value = student.last_name;
          contactNumberInput.value = student.contact_number;
          gradeLevelInput.value = student.grade_level;
          enrollmentDateInput.value = student.enrollment_date;
          isEditing = true;
          cancelEditBtn.classList.remove('hidden');
          submitBtn.textContent = 'Update';
          formTitle.textContent = 'Edit Student';
        } else {
          alert('Student not found');
        }
      } else {
        alert('Failed to load students: ' + data.message);
      }
    })
    .catch(err => alert('Error: ' + err));
}

function updateStudent(student) {
  fetch(`${API_URL}?id=${student.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(student)
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'success') {
      alert('Student updated successfully!');
      fetchStudents();
      resetForm();
    } else {
      alert('Failed to update student: ' + data.message);
    }
  })
  .catch(err => alert('Error: ' + err));
}

function deleteStudent(id) {
  fetch(`${API_URL}?id=${id}`, {
    method: 'DELETE'
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'success') {
      alert('Student deleted successfully!');
      fetchStudents();
    } else {
      alert('Failed to delete student: ' + data.message);
    }
  })
  .catch(err => alert('Error: ' + err));
}

function resetForm() {
  form.reset();
  studentIdInput.value = '';
  isEditing = false;
  cancelEditBtn.classList.add('hidden');
  submitBtn.textContent = 'Create';
  formTitle.textContent = 'Add New Student';
}

fetchStudents();

</script>
</body>
</html>
