<?php
session_start();
require 'config.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

$sql = "SELECT first_name, middle_name, last_name, grade_level, enrollment_date 
        FROM students 
        WHERE last_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Junior High School Enrollment Dashboard</title>
  <link rel="stylesheet" href="studentcss.css" />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
  <div class="background-blur"></div>

  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="account_stats.php">Account Status</a></li>
      <li><a href="profile.php">Profile</a></li>
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="mailto:example@gmail.com">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="container">
    <p class="welcome">Welcome, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>! Here is your enrollment overview.</p>

    <div class="grid">
      <?php if (empty($students)): ?>
        <p>No student records found.</p>
      <?php else: ?>
        <?php foreach ($students as $student): ?>
          <section class="card">
            <h2>Student Profile</h2>
            <ul>
              <li><strong>First Name:</strong> <?= htmlspecialchars($student['first_name']) ?></li>
              <li><strong>Middle Name:</strong> <?= htmlspecialchars($student['middle_name']) ?></li>
              <li><strong>Last Name:</strong> <?= htmlspecialchars($student['last_name']) ?></li>
              <li><strong>Grade Level:</strong> <?= htmlspecialchars($student['grade_level']) ?></li>
              <li><strong>Enrollment Date:</strong> <?= htmlspecialchars($student['enrollment_date']) ?></li>
            </ul>
          </section>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <footer>
    <p>&copy; All rights reserved.</p>
  </footer>
</body>
</html>
