<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Our School</title>
  <link rel="stylesheet" href="about.css" />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
  <div class="background-blur"></div>

  <nav class="navbar">
    <ul>
      <li><a href="p1.php">Home</a></li>
      <li><a href="p2.php">Admissions</a></li>
      <li><a href="about.php" class="active">About Us</a></li>
      <li><a href="index.php">Login</a></li>
      <li class="dropdown">
        <a href="#">Contact <i class="fas fa-caret-down"></i></a>
        <ul class="dropdown-menu" role="menu">
          <li><a href="https://www.facebook.com/Jacob.Cagadas.04"><i class="fab fa-facebook"></i> Facebook</a></li>
          <li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fas fa-envelope"></i> Gmail</a></li>
        </ul>
      </li>
    </ul>
  </nav>

  <main>
    <h1>About Us</h1>

    <section class="school-info-section">
      <div class="info-container">
        <h2>Our History</h2>
        <p>
          Our School was founded with a strong commitment to providing quality education to young learners during one of the most formative stages of their lives. Since its establishment, the school has grown from a small local institution into a vibrant learning community dedicated to academic excellence, character development, and community involvement. Through the years, we have continuously adapted to meet the evolving needs of our students, embracing both traditional values and modern teaching methods.
        </p>
      </div>

      <div class="info-container">
        <h2>Our Mission</h2>
        <p>
         To nurture well-rounded students through quality education that fosters intellectual growth, moral integrity, and social responsibility. We aim to create a safe, inclusive, and inspiring environment where learners are encouraged to reach their full potential and become productive members of society.
        </p>
      </div>

      <div class="info-container">
        <h2>Our Vision</h2>
        <p>
         To be a leading Junior High School known for academic excellence, student-centered learning, and the development of future leaders who are globally competitive, morally upright, and socially aware.
        </p>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; All rights reserved.</p>
  </footer>
</body>
</html>
