<?php
session_start();
require 'config.php';

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        echo json_encode(["success" => false, "message" => "Please fill in both username and password."]);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    if (!$stmt) {
        echo json_encode(["success" => false, "message" => "Database error: " . $conn->error]);
        exit;
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password, $role);
        $stmt->fetch();

        if ($role === 'admin') {
            if ($password === 'admin') {
                $_SESSION['id'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
                echo json_encode([
                    "success" => true,
                    "message" => "Admin login successful.",
                    "role" => "admin"
                ]);
                exit;
            } else {
                echo json_encode(["success" => false, "message" => "Incorrect admin password."]);
                exit;
            }
        } else {
            if (password_verify($password, $hashed_password)) {
                $_SESSION['id'] = $id;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = $role;
                echo json_encode([
                    "success" => true,
                    "message" => "Login successful.",
                    "role" => "user"
                ]);
                exit;
            } else {
                echo json_encode(["success" => false, "message" => "Invalid password."]);
                exit;
            }
        }
    } else {
        echo json_encode(["success" => false, "message" => "User not found."]);
        exit;
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
    exit;
}
?>
