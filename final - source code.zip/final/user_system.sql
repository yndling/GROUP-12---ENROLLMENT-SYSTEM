CREATE DATABASE IF NOT EXISTS user_system;

USE user_system;

CREATE TABLE students (
    id INT(11) NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    last_name VARCHAR(100) NOT NULL,
    student_id VARCHAR(20) DEFAULT NULL,
    contact_number VARCHAR(20) NOT NULL,
    grade_level INT(11) NOT NULL,
    enrollment_date DATE NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY student_id (student_id)
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE enrollment (
    id INT(11) NOT NULL AUTO_INCREMENT,
    fullname VARCHAR(100) NOT NULL,
    birthdate DATE NOT NULL,
    address TEXT NOT NULL,
    number VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    grade VARCHAR(10) NOT NULL,
    documents TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    payment_status VARCHAR(20) DEFAULT 'Pending',
    student_id INT(11) DEFAULT NULL,
    PRIMARY KEY (id)
);