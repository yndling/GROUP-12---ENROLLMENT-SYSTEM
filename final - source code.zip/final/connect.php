<?php
session_start();
require_once 'config.php';

// Load PHPMailer 
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $grade = strtoupper(trim($_POST['grade'])); 

    $name_parts = preg_split('/\s+/', trim($fullname));
    if (count($name_parts) < 2) {
    echo "<script>alert('Please enter at least your first and last name.'); window.history.back();</script>";
    exit();
    }


 
    $birthDateTime = new DateTime($birthdate);
    $currentDate = new DateTime();
    $age = $birthDateTime->diff($currentDate)->y;

    if ($age < 12) {
        echo "<script>alert('You must be at least 12 years old to enroll.'); window.history.back();</script>";
        exit();
    }

    //Grade validation
    $allowed_grades = ['GRADE 7', 'GRADE 8', 'GRADE 9', 'GRADE 10'];
    if (!in_array($grade, $allowed_grades)) {
        echo "<script>alert('Only Grade 7 to 10 are allowed for enrollment.'); window.history.back();</script>";
        exit();
    }

    $upload_dir = "uploads/";
    $uploaded_files = [];

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    foreach ($_FILES['documents']['name'] as $key => $filename) {
        $tmp_name = $_FILES['documents']['tmp_name'][$key];
        $file_path = $upload_dir . basename($filename);

        if (move_uploaded_file($tmp_name, $file_path)) {
            $uploaded_files[] = $file_path;
        }
    }

    $documents = implode(",", $uploaded_files);

    $stmt = $conn->prepare("INSERT INTO enrollment (fullname, birthdate, address, contact_number, email, grade, documents) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssss", $fullname, $birthdate, $address, $contact, $email, $grade, $documents);

    if ($stmt->execute()) {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'carlvesteralbarina@gmail.com';
            $mail->Password = 'vxafwdhojalxaiyv'; 

            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('carlvesteralbarina@gmail.com', 'Our School Enrollment');
            $mail->addAddress($email, $fullname);

            $mail->isHTML(true);

            $paymentUrl = 'http://localhost/final/payment.php';

            $mail->Subject = 'Enrollment Downpayment Instructions';
            $mail->Body = "
                Dear $fullname,<br><br>
                Thank you for enrolling at Our School.<br><br>
                Please proceed to pay your enrollment downpayment by clicking the link below. Also please 
                input the correct fullname what you fill up in the enrollment form and the exact grade, so the system 
                can verified your account Thank YOU:<br><br>
                <a href='$paymentUrl' target='_blank'>Pay Your Enrollment Downpayment</a><br><br>
                If the link doesn’t work, please copy and paste this URL into your browser:<br>
                $paymentUrl<br><br>
                Visit or contact the school for more details.<br><br>
                - Our School Enrollment Team
            ";

            $mail->send();

            echo "<script>alert('Enrollment successful! A confirmation email has been sent.'); window.location.href='p2.php';</script>";

        } catch (Exception $e) {
            $error = $mail->ErrorInfo;
            echo "<script>alert('Enrollment successful, but email could not be sent. Mailer Error: $error'); window.location.href='p2.php';</script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>
