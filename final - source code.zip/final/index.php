<?php
session_start();

if (isset($_SESSION["student_id"])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login & Register</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
  <!-- Navigation Bar -->
  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="p1.php">Home</a></li>
      <li><a href="p2.php">Admissions</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="index.php">Login</a></li>
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>

  <div class="container">
    
      <form id="login-form" action="login.php" method="POST">
          <h2>Login</h2>
          <input type="text" id="login-username" name="username" placeholder="Username" required>
          <input type="password" id="login-password" name="password" placeholder="Password" required>
          <button type="submit">Login</button>
          <p><a href="#">Forgot Password?</a></p>
          <p>Don't have an account? <a href="#" id="show-register">Sign up</a></p>
      </form>

      <form id="register-form" action="register.php" method="POST" style="display: none;">
          <h2>Register</h2>
          <p>TO CREATE ACCOUNT USE YOUR LASTNAME.</p> <!-- Instruction added -->
          <input type="text" id="register-username" name="username" placeholder="Username" required>
          <input type="email" id="register-email" name="email" placeholder="Email" required>
          <input type="password" id="register-password" name="password" placeholder="Password" required>

          <select id="register-role" name="role" required>
              <option value="user" selected>User</option>
              <option value="admin">Admin</option>
          </select>

          <button type="submit">Sign Up</button>
          <p>Already have an account? <a href="#" id="show-login">Login</a></p>
      </form>
  </div>

<script>
document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const showRegister = document.getElementById("show-register");
  const showLogin = document.getElementById("show-login");

  showRegister.addEventListener("click", function (e) {
    e.preventDefault();
    loginForm.style.display = "none";
    registerForm.style.display = "block";
    clearMessages();
  });

  showLogin.addEventListener("click", function (e) {
    e.preventDefault();
    registerForm.style.display = "none";
    loginForm.style.display = "block";
    clearMessages();
  });

  function clearMessages() {
    document.querySelectorAll(".form-message").forEach(msg => msg.remove());
  }

  
  registerForm.addEventListener("submit", function (e) {
    e.preventDefault();
    clearMessages();

    const formData = new FormData(registerForm);

    fetch("register.php", {
      method: "POST",
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      const msg = document.createElement("p");
      msg.className = "form-message";
      msg.textContent = data.message;
      msg.style.color = data.success ? "limegreen" : "red";
      registerForm.appendChild(msg);

      if (data.success) {
        setTimeout(() => {
          registerForm.reset();
          showLogin.click();
        }, 1500);
      }
    })
    .catch(() => {
      const msg = document.createElement("p");
      msg.className = "form-message";
      msg.style.color = "red";
      msg.textContent = "An error occurred. Please try again.";
      registerForm.appendChild(msg);
    });
  });

  
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();
    clearMessages();

    const formData = new FormData(loginForm);

    fetch("login.php", {
      method: "POST",
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      const msg = document.createElement("p");
      msg.className = "form-message";
      msg.textContent = data.message;
      msg.style.color = data.success ? "limegreen" : "red";
      loginForm.appendChild(msg);

      if (data.success) {
        const redirectUrl = (data.role === "admin") ? "admin_dashboard.php" : "dashboard.php";
        setTimeout(() => {
          window.location.href = redirectUrl;
        }, 1000);
      }
    })
    .catch(() => {
      const msg = document.createElement("p");
      msg.className = "form-message";
      msg.style.color = "red";
      msg.textContent = "An error occurred. Please try again.";
      loginForm.appendChild(msg);
    });
  });
});
</script>


</body>
</html>
