<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>WELCOME ENROLLEES!</title>
  <link rel="stylesheet" href="p1.css"/>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
  <div class="background-blur"></div>

  <nav class="navbar">
    <ul>
      <li><a href="p1.php">Home</a></li>
      <li><a href="p2.php">Admissions</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="index.php">Login</a></li>
      <li class="dropdown">
        <a href="#">Contact <i class="fa fa-caret-down"></i></a>
        <ul class="dropdown-menu">
          <li><a href="https://www.facebook.com/Jacob.Cagadas.04"><i class="fab fa-facebook"></i> Facebook</a></li>
          <li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fas fa-envelope"></i> Gmail</a></li>
        </ul>
      </li>
    </ul>
  </nav>

  <main>
    <h1>WELCOME ENROLLEES!</h1>
    <a href="p2.php"><button class="main-button">ENROLL NOW!</button></a>

    <section class="school-info-section">
      <div class="info-container">
        <h2>About Our School</h2>
        <p>
          At our school, we are committed to providing a nurturing and dynamic learning environment that fosters academic excellence, personal growth, and community responsibility. With a proud legacy of educating young minds, our school offers a well-rounded curriculum designed to prepare students for the challenges of senior high school and beyond. Through innovative teaching, dedicated faculty, and strong values, we guide students to become confident, capable, and compassionate individuals.
        </p>
      </div>
      <div class="info-container">
        <h2>Why Choose Us?</h2>
        <ul>
          <li><strong>Dedicated Teachers::</strong> Passionate and experienced educators committed to each student’s success.</li>
          <li><strong>Safe & Supportive Environment:</strong> A school culture that promotes respect, discipline, and inclusion.</li>
          <li><strong>Modern Facilities:</strong>  Classrooms equipped with up-to-date technology and resources for enhanced learning.</li>
          <li><strong>Holistic Development:</strong> Emphasis on academics, leadership, values, and extracurricular involvement.</li>
          <li><strong>Community Engagement:</strong> Strong ties with families and the community to support student growth.</li>
        </ul>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; All rights reserved.</p>
  </footer>
</body>
</html>
