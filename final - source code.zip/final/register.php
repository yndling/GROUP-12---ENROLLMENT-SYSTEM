<?php
session_start();
require "config.php";

header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $role = isset($_POST["role"]) ? trim($_POST["role"]) : 'user';

    if (empty($username) || empty($email) || empty($password)) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    if (!in_array($role, ['user', 'admin'])) {
        echo json_encode(["success" => false, "message" => "Invalid role."]);
        exit;
    }

    // Enforce "admin" password rule
    if ($role === 'admin' && $password !== 'admin') {
        echo json_encode(["success" => false, "message" => "To register as admin, you must use the password given to you."]);
        exit;
    }

    // Only hash password if not admin
    $hashed_password = ($role === 'admin') ? $password : password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $email, $hashed_password, $role);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Registration successful. Redirecting to login...",
            "redirect" => "index.php"
        ]);
        exit;

    } catch (mysqli_sql_exception $e) {
        echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
        exit;
    }
}
?>
