<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Enroll Now - Our School</title>

  <!-- Google Font Bebas Neue -->
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />

  <!-- Font Awesome -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  />

  <!-- Custom CSS -->
  <link rel="stylesheet" href="enroll.css" />
</head>
<body>
  <!-- Blurred background -->
  <div class="background-blur"></div>

  <!-- Sticky Navigation Bar -->
  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="p1.php">Home</a></li>
      <li><a href="p2.php" class="active">Admissions</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="index.php">Login</a></li>
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
    </ul>
  </nav>

  <h1 class="page-heading">BE PART OF OUR SCHOOL NOW!</h1>

  <!-- Main container for enrollment form -->
  <main>
    <div class="container">
      <form id="enrollForm" action="connect.php" method="post" class="enroll-form" aria-label="Enrollment Form" enctype="multipart/form-data" onsubmit="return validateFullName();">
        <input type="text" name="fullname" placeholder="FULL NAME" required aria-required="true" autocomplete="name" />
        <input type="date" name="birthdate" aria-label="Birth Date" required aria-required="true" />
        <input type="text" name="address" placeholder="ADDRESS" required aria-required="true" autocomplete="street-address" />
        <input type="tel" name="contact" placeholder="PHONE NUMBER" required aria-required="true" autocomplete="tel" pattern="[0-9+\-\s]{7,15}" title="Please enter a valid phone number" />
        <input type="email" name="email" placeholder="EMAIL" required aria-required="true" autocomplete="email" />

        <select name="grade" required aria-required="true">
          <option value="" disabled selected>Select Grade</option>
          <option value="Grade 7">Grade 7</option>
          <option value="Grade 8">Grade 8</option>
          <option value="Grade 9">Grade 9</option>
          <option value="Grade 10">Grade 10</option>
        </select>

        <label for="documents" class="upload-label" tabindex="0" aria-label="Upload your documents here">
          <span>UPLOAD YOUR DOCUMENTS HERE</span>
          <span class="plus">+</span>
        </label>
        <input type="file" id="documents" name="documents[]" multiple required aria-required="true" hidden />

        <div class="buttons">
          <a href="p2.php" class="go-back" role="button" tabindex="0">Go Back</a>
          <button type="submit" class="main-button">Submit</button>
        </div>
      </form>
    </div>
  </main>

  <footer>
    <p>&copy; All rights reserved.</p>
  </footer>

  <script>
    const uploadLabel = document.querySelector('.upload-label');
    const fileInput = document.getElementById('documents');
    uploadLabel.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        fileInput.click();
      }
    });
  </script>
  <script>
  function validateFullName() {
    const fullNameInput = document.querySelector('input[name="fullname"]');
    const fullName = fullNameInput.value.trim();

    // Split name by whitespace
    const nameParts = fullName.split(/\s+/);

    if (nameParts.length < 2) {
      alert('Please enter at least your first and last name.');
      fullNameInput.focus();
      return false;
    }

    return true;
  }
</script>

</body>
</html>
