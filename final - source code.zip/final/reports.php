<?php
session_start();
require 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reports</title>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="reports.css" />
  <style>
    body {
      background-color: #0A192F;
      padding-top: 80px; 
    }

    h2 {
      color: white;
      text-align: center;
    }
  </style>
</head>
<body>

  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="admin_dashboard.php">DASHBOARD</a></li>
      <li><a href="reports.php">Reports</a></li>
      
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="account-status-container">
    <h2>Account Status</h2>

    <form method="GET" action="reports.php" style="text-align: center; margin-bottom: 20px;">
      <label for="gradeFilter" style="color: white; font-size: 18px;">
        Select Grade:
      </label>
      <select name="grade" id="gradeFilter" onchange="this.form.submit()" style="padding: 8px 12px; font-size: 16px; border-radius: 6px; border: none;">
        <option value="all" <?= (!isset($_GET['grade']) || $_GET['grade'] == 'all') ? 'selected' : '' ?>>All Grades</option>
        <option value="Grade 7" <?= (isset($_GET['grade']) && $_GET['grade'] == 'Grade 7') ? 'selected' : '' ?>>Grade 7</option>
        <option value="Grade 8" <?= (isset($_GET['grade']) && $_GET['grade'] == 'Grade 8') ? 'selected' : '' ?>>Grade 8</option>
        <option value="Grade 9" <?= (isset($_GET['grade']) && $_GET['grade'] == 'Grade 9') ? 'selected' : '' ?>>Grade 9</option>
        <option value="Grade 10" <?= (isset($_GET['grade']) && $_GET['grade'] == 'Grade 10') ? 'selected' : '' ?>>Grade 10</option>
      </select>
    </form>

    <table class="status-table">
      <thead>
        <tr>
          <th>Full Name</th>
          <th>Contact Number</th>
          <th>Grade</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody id="accountStatusBody">
        <?php
        $selectedGrade = $_GET['grade'] ?? 'all';

        if ($selectedGrade === 'all') {
            $sql = "SELECT fullname, contact_number, grade, payment_status FROM enrollment ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
        } else {
            $sql = "SELECT fullname, contact_number, grade, payment_status FROM enrollment WHERE grade = ? ORDER BY id DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $selectedGrade);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $fullname = $row['fullname'];
                $contact = $row['contact_number'];
                $grade = $row['grade'];
                $status = $row['payment_status'] === 'Paid' ? 'Paid' : 'Pending';
                $status_class = $status === 'Paid' ? 'status-paid' : 'status-pending';

                echo "<tr>
                        <td>$fullname</td>
                        <td>$contact</td>
                        <td>$grade</td>
                        <td><span class='$status_class'>$status</span></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4' style='color:white; text-align:center;'>No enrollments found for selected grade</td></tr>";
        }

        $stmt->close();
        $conn->close();
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>
