<?php
require_once 'config.php'; // database connection

require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';
require 'phpmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = ucwords(strtolower(trim($_POST['studentName'])));
    $grade = "Grade " . trim($_POST['courseSelect']);
    $amount = floatval($_POST['paymentAmount']);

    if (empty($name) || empty($grade) || $amount < 350) {
        echo "<script>alert('Invalid input. Please check all fields.'); window.location.href='payment.php';</script>";
        exit;
    }

    // Search for student including email
    $stmt = $conn->prepare("SELECT id, email FROM enrollment WHERE fullname = ? AND grade = ?");
    $stmt->bind_param("ss", $name, $grade);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $email);
        $stmt->fetch();

        // Update status to Paid
        $update = $conn->prepare("UPDATE enrollment SET payment_status = 'Paid' WHERE id = ?");
        $update->bind_param("i", $id);
        $update->execute();
        $update->close();

        // Send email confirmation
        if (!empty($email)) {
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';  // Set your SMTP server here
                $mail->SMTPAuth = true;
                $mail->Username = 'carlvesteralbarina@gmail.com'; // SMTP username
                $mail->Password = 'vxafwdhojalxaiyv';   // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Encryption
                $mail->Port = 587; // TCP port

                // Recipients
                $mail->setFrom('carlvesteralbarina@gmail.com', 'Enrollment Office');
                $mail->addAddress($email, $name);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Payment Confirmation - Enrollment Fee Paid';
                $mail->Body = "
                    <h2>Payment Confirmation</h2>
                    <p>Dear {$name},</p>
                    <p>Thank you for your payment of ₱{$amount} for {$grade} enrollment.</p>
                    <p>Your payment status has been updated to <strong>Paid</strong>.</p>
                    <p>If you have any questions, feel free to contact us.</p>
                    <br>
                    <p>Best regards,<br>Enrollment Office</p>
                ";

                $mail->send();
            } catch (Exception $e) {
                // Optional: Log email sending error
                error_log("Mailer Error: " . $mail->ErrorInfo);
            }
        }

        echo "<script>alert('Payment successful! Status updated to Paid. A confirmation email has been sent.'); window.location.href='p2.php';</script>";
    } else {
        echo "<script>alert('Student not found. Please check the name and grade.'); window.location.href='payment.php';</script>";
    }

    $stmt->close();
    $conn->close();
    exit;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Enrollment Payment</title>
  <link rel="stylesheet" href="payment.css" />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
</head>
<body>

  <div class="container">
    <h1>Enrollment Payment</h1>

    <div class="form-and-qr">
      <form id="enrollmentForm" method="POST" action="payment.php" novalidate>
        <div class="form-group">
          <label for="studentName">Student Name</label>
          <input
            type="text"
            id="studentName"
            name="studentName"
            placeholder="Enter student name"
            required
            minlength="3"
            pattern="[a-zA-Z\s]+"
            title="Please enter only letters and spaces, minimum 3 characters"
          />
        </div>

        <div class="form-group">
          <label for="courseSelect">Select Grade</label>
          <select id="courseSelect" name="courseSelect" required>
            <option value="" disabled selected>Select Grade</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
          </select>
        </div>

        <div class="form-group">
          <label for="paymentAmount">Payment Amount (₱350)</label>
          <input
            type="number"
            id="paymentAmount"
            name="paymentAmount"
            placeholder="Enter payment amount"
            min="350"
            required
            title="Minimum payment is ₱350"
          />
        </div>

        <div class="button-container">  
          <button type="submit" class="btn-create">Pay Enrollment Fee</button>
        </div>
      </form>

      <div class="qr-container">
        <img src="scan.jpeg.jpg" alt="QR Code" title="Scan this QR code to pay with GCash" />
        <p>Scan to pay with GCash</p>
      </div>
    </div>

    <p id="thankYouMessage" aria-live="polite">Thank you for paying!</p>
  </div>

</body>
</html>
