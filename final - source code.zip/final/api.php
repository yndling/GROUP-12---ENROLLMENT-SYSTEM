<?php
require 'config.php';

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

function sendResponse($status, $message, $data = null, $code = 200) {
    http_response_code($code);
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]);
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        createStudent($conn);
        break;
    case 'PUT':
        updateStudent($conn);
        break;
    case 'DELETE':
        deleteStudent($conn);
        break;
    case 'GET':
        getStudents($conn);
        break;
    default:
        sendResponse('error', 'Invalid request method', null, 405);
        break;
}

// CREATE
function createStudent($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $first = $input['first_name'] ?? null;
    $middle = $input['middle_name'] ?? null;
    $last = $input['last_name'] ?? null;
    $contact = $input['contact_number'] ?? null;
    $grade = $input['grade_level'] ?? null;
    $date = $input['enrollment_date'] ?? null;

    if (!$first || !$last || !$contact || !$grade || !$date) {
        sendResponse('error', 'Missing required fields', null, 400);
        return;
    }

    $stmt = $conn->prepare("INSERT INTO students (first_name, middle_name, last_name, contact_number, grade_level, enrollment_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $first, $middle, $last, $contact, $grade, $date);

    if ($stmt->execute()) {
        sendResponse('success', 'Student created successfully');
    } else {
        sendResponse('error', 'Failed to create student', null, 500);
    }
    $stmt->close();
}

// UPDATE
function updateStudent($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $id = $input['id'] ?? null;
    $first = $input['first_name'] ?? null;
    $middle = $input['middle_name'] ?? null;
    $last = $input['last_name'] ?? null;
    $contact = $input['contact_number'] ?? null;
    $grade = $input['grade_level'] ?? null;
    $date = $input['enrollment_date'] ?? null;

    if (!$id || !$first || !$last || !$contact || !$grade || !$date) {
        sendResponse('error', 'Missing required fields', null, 400);
        return;
    }

    $stmt = $conn->prepare("UPDATE students SET first_name=?, middle_name=?, last_name=?, contact_number=?, grade_level=?, enrollment_date=? WHERE id=?");
    $stmt->bind_param("ssssssi", $first, $middle, $last, $contact, $grade, $date, $id);

    if ($stmt->execute()) {
        sendResponse('success', 'Student updated successfully');
    } else {
        sendResponse('error', 'Failed to update student', null, 500);
    }
    $stmt->close();
}

// DELETE
function deleteStudent($conn) {
    // Parse the query string manually
    parse_str($_SERVER['QUERY_STRING'], $queryParams);
    $id = isset($queryParams['id']) ? intval($queryParams['id']) : null;

    if (!$id) {
        sendResponse('error', 'Missing student ID', null, 400);
        return;
    }

    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        sendResponse('success', 'Student deleted successfully');
    } else {
        sendResponse('error', 'Failed to delete student', null, 500);
    }
    $stmt->close();
}

// READ
function getStudents($conn) {
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $students = [];
        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }
        sendResponse('success', 'Students retrieved successfully', $students);
    } else {
        sendResponse('success', 'No students found', []);
    }
}
