<?php
session_start();
require 'config.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['username'];

$sql = "SELECT first_name, middle_name, last_name, grade_level, enrollment_date 
        FROM students 
        WHERE last_name = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$students = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Account Status</title>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="accountstats.css" />
  <style>
    body {
      background-color: #0A192F;
      padding-top: 80px; 
    }

    h2 {
      color: white;
      text-align: center;
    }

    table {
      width: 80%;
      margin: 20px auto;
      border-collapse: collapse;
      background-color: #ffffff10;
      color: white;
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #444;
    }

    .status-paid { color: limegreen; }
  </style>
</head>
<body>

  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
      <li><a href="dashboard.php">DASHBOARD</a></li>
      <li><a href="account_stats.php">ACCOUNT STATUS</a></li>
      <li><a href="profile.php">PROFILE</a></li>
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>

  <div class="account-status-container">
    <h2>Account Status</h2>
    <table class="status-table">
      <thead>
  <tr>
    <th>First Name</th>
    <th>Middle Name</th>
    <th>Last Name</th>
    <th>Grade</th>
    <th>Enrollment Date</th>
    <th>Status</th>
  </tr>
</thead>
<tbody id="accountStatusBody">
  <?php if (!empty($students)): ?>
    <?php foreach ($students as $student): ?>
      <tr>
        <td><?= htmlspecialchars($student['first_name']) ?></td>
        <td><?= htmlspecialchars($student['middle_name']) ?></td>
        <td><?= htmlspecialchars($student['last_name']) ?></td>
        <td><?= htmlspecialchars($student['grade_level']) ?></td>
        <td><?= htmlspecialchars(date('F j, Y', strtotime($student['enrollment_date']))) ?></td>
        <td><span class="status-paid">Paid</span></td>
      </tr>
    <?php endforeach; ?>
  <?php else: ?>
    <tr>
      <td colspan="6" style="text-align:center; color: red;">No records found.</td>
    </tr>
  <?php endif; ?>
</tbody>
  </table>
    <h2>Subjects</h2>
    <table class="status-table">
      <thead>
        <tr>
          <th>Subject Name</th>
        </tr>
      </thead>
      <tbody>
        <tr><td>Mathematics</td></tr>
        <tr><td>English</td></tr>
        <tr><td>Science</td></tr>
        <tr><td>Filipino</td></tr>
        <tr><td>Araling Panlipunan</td></tr>
        <tr><td>MAPEH</td></tr>
      </tbody>
    </table>
  </div>

</body>
</html>
