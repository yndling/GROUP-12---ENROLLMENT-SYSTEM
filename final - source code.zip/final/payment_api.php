<?php
require_once 'config.php'; // DB connection

header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get raw POST data
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);

// Validate input
$name = ucwords(strtolower(trim($data['studentName'] ?? '')));
$grade = trim($data['courseSelect'] ?? '');
$amount = floatval($data['paymentAmount'] ?? 0);

// Basic validation
if (empty($name) || empty($grade) || $amount < 350) {
    echo json_encode(['success' => false, 'message' => 'Please fill all fields correctly.']);
    exit;
}

// Check if student exists
$stmt = $conn->prepare("SELECT id FROM enrollment WHERE LOWER(fullname) = LOWER(?) AND grade = ?");
$stmt->bind_param("ss", $name, $grade);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $update = $conn->prepare("UPDATE enrollment SET payment_status = 'Paid' WHERE LOWER(fullname) = LOWER(?) AND grade = ?");
    $update->bind_param("ss", $name, $grade);
    $update->execute();
    $update->close();

    echo json_encode(['success' => true, 'message' => 'Payment successful! Status updated to Paid.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Student not found. Please check the name and grade.']);
}

$stmt->close();
$conn->close();
