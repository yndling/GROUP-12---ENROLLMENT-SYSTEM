<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Student Profile</title>
  

  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  
  <link rel="stylesheet" href="profile.css" />
</head>
<body>

  <nav class="navbar" role="navigation" aria-label="Primary Navigation">
    <ul>
    <li><a href="dashboard.php">DASHBOARD</a></li>
      <li><a href="account_stats.php">ACCOUNT STATUS</a></li>
      <li><a href="profile.php">PROFILE</a></li>
      <li class="dropdown">
        <a href="#" aria-haspopup="true" aria-expanded="false">
          Contact <i class="fas fa-caret-down"></i>
        </a>
        <ul class="dropdown-menu" role="menu" aria-label="Contact submenu">
          <li>
            <a href="https://www.facebook.com/Jacob.Cagadas.04" target="_blank" rel="noopener">
              <i class="fab fa-facebook"></i> Facebook
            </a>
          </li>
          <li>
            <a href="https://mail.google.com/mail/u/0/#inbox" target="_blank" rel="noopener">
              <i class="fas fa-envelope"></i> Gmail
            </a>
          </li>
        </ul>
      </li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </nav>


  <main class="profile-wrapper">
    <section class="profile-card">
      
      <div class="profile-pic-section">
        <img src="https://i.pravatar.cc/150" alt="Profile Picture" class="profile-pic" id="profilePic" />
        <label for="profilePicInput" class="upload-btn" title="Change profile picture">
          <i class="fas fa-camera"></i>
        </label>
        <input type="file" id="profilePicInput" accept="image/*" hidden />
      </div>

      <form class="profile-form" action="#" method="post" autocomplete="off">
        <h2>Your Profile</h2>

        <div class="input-group">
          <label for="fname">First Name</label>
          <input type="text" id="fname" name="fname" placeholder="Enter your first name" required />
        </div>

        <div class="input-group">
          <label for="mname">Middle Name</label>
          <input type="text" id="mname" name="mname" placeholder="Enter your middle name" />
        </div>

        <div class="input-group">
          <label for="lname">Last Name</label>
          <input type="text" id="lname" name="lname" placeholder="Enter your last name" required />
        </div>

        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="example@example.com" required />
        </div>

        <div class="input-group">
          <label for="grade">Grade</label>
          <select id="grade" name="grade" required>
            <option value="" disabled selected>Select your grade</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
          </select>
        </div>

        <div class="input-group">
          <label for="dob">Date of Birth</label>
          <input type="date" id="dob" name="dob" required />
        </div>

        <button type="submit" class="btn-submit">Save Changes</button>
      </form>
    </section>
  </main>

  <script>
    const inputFile = document.getElementById('profilePicInput');
    const profilePic = document.getElementById('profilePic');

    inputFile.addEventListener('change', e => {
      const [file] = e.target.files;
      if (file) {
        profilePic.src = URL.createObjectURL(file);
      }
    });
  </script>

</body>
</html>
