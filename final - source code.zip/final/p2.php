<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admissions</title>
  <link rel="stylesheet" href="admission.css" />
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
  <div class="background-blur"></div>

  <nav class="navbar">
    <ul>
      <li><a href="p1.php">Home</a></li>
      <li><a href="p2.php">Admissions</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="index.php">Login</a></li>
      <li class="dropdown">
        <a href="#">Contact <i class="fa fa-caret-down"></i></a>
        <ul class="dropdown-menu">
          <li><a href="https://www.facebook.com/Jacob.Cagadas.04"><i class="fab fa-facebook"></i> Facebook</a></li>
          <li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="fas fa-envelope"></i> Gmail</a></li>
        </ul>
      </li>
    </ul>
  </nav>

  <main class="container">
    <div class="left-section">
      <h1>HOW TO ENROLL?</h1>
      <div class="steps">
        <div class="step">
          <img src="form2.webp" alt="Form Icon">
          <p>FILL UP FORM</p>
          <span>&#10003;</span>
        </div>
        <div class="step">
          <img src="report3.png" alt="Report Card Icon">
          <p>REPORT CARD</p>
          <span>&#10003;</span>
        </div>
        <div class="step">
          <img src="birth-removebg-preview.png" alt="Certificate Icon">
          <p>BIRTH CERTIFICATE</p>
          <span>&#10003;</span>
        </div>
      </div>
    </div>
    <div class="right-section">
      <img src="students.png" alt="Happy Students" class="students-image">
      <a href="p3.php"><button class="enroll-btn">ENROLL NOW</button></a>
    </div>
  </main>
</body>
</html>
