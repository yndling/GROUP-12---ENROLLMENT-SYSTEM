<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $first = $_POST['first_name'];
    $middle = $_POST['middle_name'];
    $last = $_POST['last_name'];
    $contact = $_POST['contact_number'];
    $grade = $_POST['grade_level'];
    $date = $_POST['enrollment_date'];

    $stmt = $conn->prepare("UPDATE students SET first_name=?, middle_name=?, last_name=?, contact_number=?, grade_level=?, enrollment_date=? WHERE id=?");
    $stmt->bind_param("ssssisi", $first, $middle, $last, $contact, $grade, $date, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_dashboard.php");
    exit;
}
