<?php
require 'config.php';

header('Content-Type: application/json');

function sendResponse($status, $message, $data = null) {
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]);
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':  
        createStudent($conn);
        break;
    case 'PUT':  
        updateStudent($conn);
        break;
    case 'DELETE':  
        deleteStudent($conn);
        break;
    case 'GET':  
        getStudents($conn);
        break;
    default:
        sendResponse('error', 'Invalid request method');
        break;
}

function createStudent($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $first = $input['first_name'];
    $middle = $input['middle_name'];
    $last = $input['last_name'];
    $contact = $input['contact_number'];
    $grade = $input['grade_level'];
    $date = $input['enrollment_date'];

    $stmt = $conn->prepare("INSERT INTO students (first_name, middle_name, last_name, contact_number, grade_level, enrollment_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $first, $middle, $last, $contact, $grade, $date);
    
    if ($stmt->execute()) {
        sendResponse('success', 'Student created successfully');
    } else {
        sendResponse('error', 'Failed to create student');
    }
    $stmt->close();
}

function updateStudent($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $id = $input['id'];
    $first = $input['first_name'];
    $middle = $input['middle_name'];
    $last = $input['last_name'];
    $contact = $input['contact_number'];
    $grade = $input['grade_level'];
    $date = $input['enrollment_date'];

    $stmt = $conn->prepare("UPDATE students SET first_name=?, middle_name=?, last_name=?, contact_number=?, grade_level=?, enrollment_date=? WHERE id=?");
    $stmt->bind_param("ssssisi", $first, $middle, $last, $contact, $grade, $date, $id);
    
    if ($stmt->execute()) {
        sendResponse('success', 'Student updated successfully');
    } else {
        sendResponse('error', 'Failed to update student');
    }
    $stmt->close();
}

function deleteStudent($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'];

    $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        sendResponse('success', 'Student deleted successfully');
    } else {
        sendResponse('error', 'Failed to delete student');
    }
    $stmt->close();
}

function getStudents($conn) {
    $sql = "SELECT * FROM students";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $students = [];
        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }
        sendResponse('success', 'Students retrieved successfully', $students);
    } else {
        sendResponse('error', 'No students found');
    }
}
?>
